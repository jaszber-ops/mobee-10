// Møbee Multi - Version
export const VERSION = '1.2.7';
export const BUILD_DATE = new Date().toISOString();

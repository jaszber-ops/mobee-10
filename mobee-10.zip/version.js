// Møbee Multi - Version
export const VERSION = '1.5.68';
export const BUILD_DATE = new Date().toISOString();

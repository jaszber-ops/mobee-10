// party/server.js
import { generateDeck } from "./game-math.js";

// Level thresholds
const LEVEL_UP_THRESHOLD = 6;    // Score to reach level 2
const LEVEL_DOWN_THRESHOLD = 0;  // Score to drop back to level 1 (when on level 2)

// Fisher-Yates shuffle for unbiased random selection
function fisherYatesShuffle(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export default class MobeeServer {
  constructor(party) {
    this.party = party;
    this._queue = Promise.resolve();
  }

  // Helper to get deck positions based on level
  getDeckPositions(level) {
    if (level === 2) {
      // Level 2 has 10 cards, use positions that cycle through unique 3-card combos
      return [0, 3, 6, 9, 2, 5, 8, 1, 4, 7];
    }
    // Level 1 has 8 cards
    return [0, 3, 6, 1, 4, 7, 2, 5];
  }

  // Helper method to generate and broadcast a new round
  async startNewRound(state) {
    // Don't start a new round if the game has ended
    if (!state.gameStartTime) {
      console.log("startNewRound called but gameStartTime is null - game has ended");
      return;
    }

    const shuffleArray = (arr) => fisherYatesShuffle(arr);
    const level = state.currentLevel || 1;
    const DECK_POSITIONS = this.getDeckPositions(level);
    const deckSize = state.deck.length;

    // Initialize or advance deck position
    if (state.deckPositionIndex === undefined || state.deckPositionIndex === null) {
      // First round - shuffle deck order and start at position 0
      state.shuffledDeckOrder = fisherYatesShuffle([...Array(deckSize).keys()]);
      state.deckPositionIndex = 0;
      console.log("New game - shuffled deck order:", state.shuffledDeckOrder);
    } else {
      // Advance to next position
      state.deckPositionIndex = (state.deckPositionIndex + 1) % DECK_POSITIONS.length;

      // If we've cycled back to 0, reshuffle the deck
      if (state.deckPositionIndex === 0) {
        state.shuffledDeckOrder = fisherYatesShuffle([...Array(deckSize).keys()]);
        console.log("Deck exhausted - reshuffled deck order:", state.shuffledDeckOrder);
      }
    }

    // Get the starting position for this round's 3-card hand
    const startPos = DECK_POSITIONS[state.deckPositionIndex];

    // Get 3 consecutive cards from shuffled deck (wrapping around)
    const deckOrder = state.shuffledDeckOrder;
    const idx1 = deckOrder[startPos % deckSize];
    const idx2 = deckOrder[(startPos + 1) % deckSize];
    const idx3 = deckOrder[(startPos + 2) % deckSize];

    console.log("Level:", level, "| Position index:", state.deckPositionIndex, "| Card indices:", idx1, idx2, idx3);

    // Shuffle symbols within each card
    const c1 = shuffleArray(state.deck[idx1]);
    const c2 = shuffleArray(state.deck[idx2]);
    const c3 = shuffleArray(state.deck[idx3]);

    // Store which deck indices we used
    state.currentDeckIndices = [idx1, idx2, idx3];

    const answer = c1.find(s => c2.includes(s) && c3.includes(s));

    console.log("Common symbol (answer):", answer);

    state.currentAnswer = answer;
    state.currentShuffledCards = [c1, c2, c3];
    state.status = "playing";

    this.party.broadcast(JSON.stringify({
      type: "NEW_ROUND",
      cards: [c1, c2, c3],
      level: level,
      gameStartTime: state.gameStartTime,
      scores: state.scores,
      playerLevels: state.playerLevels,
      avatars: state.avatars,
      hostId: state.hostId
    }));

    await this.party.storage.put("gamestate", state);
  }

  // Helper to switch to a new level
  async switchLevel(state, newLevel) {
    console.log("Switching to level", newLevel);
    state.currentLevel = newLevel;

    // Generate new deck for the level
    const deckData = generateDeck(newLevel);
    state.deck = deckData.cards;
    state.symbolSet = deckData.symbolSet;

    // Reset deck position for fresh shuffle
    state.deckPositionIndex = null;
    state.shuffledDeckOrder = null;

    return state;
  }

  async onConnect(conn) {
    // Extract persistent playerId from query params
    const playerId = new URL(conn.uri).searchParams.get('playerId') || conn.id;

    // Store playerId on connection object for later use
    conn.playerId = playerId;

    // Generate server-side session token to prevent spoofing
    const sessionToken = crypto.randomUUID();
    conn.sessionToken = sessionToken;

    // Initialize rate limiting for this connection
    conn.lastGuessTime = 0;

    console.log("Player connected:", playerId, "(conn:", conn.id, "token:", sessionToken.slice(0, 8) + "...)");

    let state = await this.party.storage.get("gamestate");

    if (!state) {
      const deckData = generateDeck(1); // Start with level 1
      state = {
        deck: deckData.cards,
        symbolSet: deckData.symbolSet,
        currentLevel: 1,
        status: "waiting",
        scores: {},
        playerLevels: {},
        avatars: {},
        currentAnswer: null,
        gameStartTime: null,
        countdownStartAt: null,
        hostId: playerId  // First player to join becomes host
      };
      await this.party.storage.put("gamestate", state);
    }

    // Initialize avatars and playerLevels objects if they don't exist
    if (!state.avatars) state.avatars = {};
    if (!state.playerLevels) state.playerLevels = {};
    if (!state.currentLevel) state.currentLevel = 1;

    // Initialize hostId for old rooms that don't have it
    if (!state.hostId) {
      const existingPlayers = Object.keys(state.scores);
      state.hostId = existingPlayers.length > 0 ? existingPlayers.sort()[0] : playerId;
      console.log("Initialized missing hostId to:", state.hostId);
    }

    // Clean up zombie players
    const activePlayerIds = [...this.party.getConnections()].map(c => c.playerId).filter(Boolean);
    const statePlayerIds = Object.keys(state.scores);
    const zombiePlayers = statePlayerIds.filter(id => !activePlayerIds.includes(id) && id !== playerId);

    if (zombiePlayers.length > 0) {
      console.log("Cleaning up zombie players:", zombiePlayers);
      zombiePlayers.forEach(zombieId => {
        delete state.scores[zombieId];
        delete state.avatars[zombieId];
        delete state.playerLevels[zombieId];
      });
      await this.party.storage.put("gamestate", state);
    }

    // Check player limit (max 5 players)
    const existingPlayerCount = Object.keys(state.scores).length;
    const isNewPlayer = !state.scores[playerId];

    if (isNewPlayer && existingPlayerCount >= 5) {
      console.log("Room full - rejecting player:", playerId);
      conn.send(JSON.stringify({
        type: "ROOM_FULL",
        message: "This room is full (max 5 players). Please try a different room."
      }));
      conn.close();
      return;
    }

    // Reset gameStartTime only if time has actually expired
    // Don't reset just because status is "waiting" - that happens between rounds during active gameplay
    if (state.gameStartTime) {
      const elapsed = Math.floor((Date.now() - state.gameStartTime) / 1000);

      if (elapsed >= 60) {
        console.log("Resetting gameStartTime (elapsed:", elapsed, "s >= 60)");
        state.gameStartTime = null;
        state.status = "waiting";
        await this.party.storage.put("gamestate", state);
      }
    }

    // Reset stale countdowns
    if (state.status === "countdown") {
      const countdownAge = state.countdownStartAt ? Date.now() - state.countdownStartAt : null;
      const isCountdownStale = countdownAge === null || countdownAge > 5000;
      const playerCount = Object.keys(state.scores).length;

      if (isCountdownStale || playerCount <= 1) {
        console.log("Resetting stale countdown");
        state.status = "waiting";
        state.countdownStartAt = null;
        await this.party.storage.put("gamestate", state);
      }
    }

    // Check if player was already in the game
    const isReturningPlayer = state.scores[playerId] !== undefined;

    // Add player to scores if new
    if (!isReturningPlayer) {
      state.scores[playerId] = 0;
      state.playerLevels[playerId] = 1; // New players start at level 1

      this.party.broadcast(JSON.stringify({
        type: "UPDATE_SCORES",
        scores: state.scores,
        playerLevels: state.playerLevels,
        avatars: state.avatars,
        hostId: state.hostId
      }));

      await this.party.storage.put("gamestate", state);
    }

    // Send session token to client
    conn.send(JSON.stringify({
      type: "SESSION",
      sessionToken: sessionToken
    }));

    // Send current game state to the connecting player
    const playerCount = Object.keys(state.scores).length;

    if (state.status === "countdown") {
      console.log("Player joining during countdown");
      conn.send(JSON.stringify({
        type: "GAME_STARTING",
        countdown: 3,
        scores: state.scores,
        playerLevels: state.playerLevels,
        avatars: state.avatars,
        hostId: state.hostId
      }));
    } else if (state.status === "playing" && state.currentShuffledCards && !isReturningPlayer && playerCount > 1) {
      console.log("New player joining mid-game - spectating");
      conn.send(JSON.stringify({
        type: "JOIN_AS_SPECTATOR",
        cards: state.currentShuffledCards,
        level: state.currentLevel,
        gameStartTime: state.gameStartTime,
        scores: state.scores,
        playerLevels: state.playerLevels,
        avatars: state.avatars,
        hostId: state.hostId
      }));
    } else {
      conn.send(JSON.stringify({
        type: "UPDATE_SCORES",
        scores: state.scores,
        playerLevels: state.playerLevels,
        avatars: state.avatars,
        hostId: state.hostId
      }));
    }
  }

  async onMessage(message, sender) {
    this._queue = this._queue.then(() => this._handleMessage(message, sender)).catch(console.error);
  }

  async _handleMessage(message, sender) {
    let data;
    try {
      data = JSON.parse(message);
    } catch (e) {
      console.log("Invalid JSON message:", message);
      return;
    }

    let state = await this.party.storage.get("gamestate");

    if (data.type === "START_GAME") {
      console.log("Starting new game...", data.skipLevelUp ? "(skipping level up)" : "");

      const isNewGame = !state.gameStartTime || state.status === "waiting";
      const playerCount = Object.keys(state.scores).length;
      const isMultiplayer = playerCount > 1;
      const skipLevelUp = data.skipLevelUp === true;

      if (isNewGame) {
        if (state.status === "countdown") {
          const countdownAge = state.countdownStartAt ? Date.now() - state.countdownStartAt : null;
          const isCountdownStale = countdownAge === null || countdownAge > 5000;
          if (!isCountdownStale) {
            console.log("Countdown already in progress, ignoring START_GAME");
            return;
          }
          state.status = "waiting";
          state.countdownStartAt = null;
        }

        // If skipping level up, clear qualifications and reset all players to level 1
        if (skipLevelUp) {
          console.log("Skipping level up - resetting to level 1");
          state.qualifiedForLevel = {};
          // Reset all players to level 1
          for (const pid of Object.keys(state.playerLevels || {})) {
            state.playerLevels[pid] = 1;
          }
          state.currentLevel = 1;
          await this.party.storage.put("gamestate", state);
        }

        const startActualGame = async () => {
          let currentState = await this.party.storage.get("gamestate");

          if (isMultiplayer && currentState.status !== "countdown") {
            console.log("Countdown interrupted, not starting game");
            return;
          }

          currentState.gameStartTime = Date.now();
          currentState.gameEndsAt = Date.now() + 60000;
          currentState.countdownStartAt = null;

          // Capture previous scores BEFORE resetting (for level drop check)
          const previousScores = { ...currentState.scores };
          const playerIds = Object.keys(previousScores);
          const isSinglePlayer = playerIds.length === 1;

          // Reset all scores to 0 at game start
          currentState.scores = Object.fromEntries(
            playerIds.map(id => [id, 0])
          );

          // Check if any player qualified for level 2 (from previous game)
          const qualifiedPlayers = currentState.qualifiedForLevel || {};
          const currentPlayerLevels = currentState.playerLevels || {};

          // Apply qualifications: check if any player qualified for level 2 or is already on level 2
          let startingLevel = 1;

          // Check if any player qualified for level 2 or is already on level 2 with good score
          for (const playerId of playerIds) {
            const currentLevel = currentPlayerLevels[playerId] || 1;
            const previousScore = previousScores[playerId] || 0;

            if (qualifiedPlayers[playerId] === 2) {
              startingLevel = 2;
              console.log("🎉 Player", playerId, "starting at Level 2 (qualified from previous game)");
              break; // Any player qualifying moves everyone to level 2
            } else if (currentLevel === 2 && previousScore > LEVEL_DOWN_THRESHOLD) {
              // Player was already on level 2 and scored > 0 - stay on level 2
              startingLevel = 2;
              console.log("🔄 Player", playerId, "continuing at Level 2 (scored", previousScore, ")");
              break;
            }
          }

          // Set player levels based on qualification and score
          currentState.playerLevels = Object.fromEntries(
            playerIds.map(id => {
              const currentLevel = currentPlayerLevels[id] || 1;
              const previousScore = previousScores[id] || 0;
              // If qualified for level 2, use that
              if (qualifiedPlayers[id] === 2) {
                return [id, 2];
              }
              // If on level 2 but scored 0, drop to level 1
              if (currentLevel === 2 && previousScore <= LEVEL_DOWN_THRESHOLD) {
                return [id, 1];
              }
              // Otherwise keep current level
              return [id, currentLevel];
            })
          );
          currentState.currentLevel = startingLevel;

          // Clear qualifications after applying
          currentState.qualifiedForLevel = {};

          // Reset deck position
          currentState.deckPositionIndex = null;
          currentState.shuffledDeckOrder = null;

          // Generate deck for the starting level
          const deckData = generateDeck(startingLevel);
          currentState.deck = deckData.cards;
          currentState.symbolSet = deckData.symbolSet;
          console.log("New game - Level", startingLevel, ", symbols:", currentState.symbolSet);

          await this.startNewRound(currentState);

          // Schedule server-side game end check (runs periodically to check gameEndsAt)
          // This is only needed for multiplayer - single player uses END_GAME message
          const gameStartTime = currentState.gameStartTime;
          const checkGameEnd = async () => {
            const endState = await this.party.storage.get("gamestate");

            // If game was reset or different game, stop checking
            if (!endState || endState.gameStartTime !== gameStartTime) {
              console.log("checkGameEnd: game state changed, stopping checks");
              return;
            }

            // Check if game time has expired
            if (endState.gameEndsAt && Date.now() >= endState.gameEndsAt) {
              console.log("Server forcing GAME_OVER (gameEndsAt reached:", endState.gameEndsAt, "now:", Date.now(), ")");

              // Check if any player qualified for level 2 (scored >= 6 while on level 1)
              if (!endState.qualifiedForLevel) endState.qualifiedForLevel = {};
              for (const [playerId, score] of Object.entries(endState.scores)) {
                const currentLevel = endState.playerLevels[playerId] || 1;
                if (score >= LEVEL_UP_THRESHOLD && currentLevel === 1) {
                  endState.qualifiedForLevel[playerId] = 2;
                  console.log("🎉 Player", playerId, "qualified for Level 2 (scored", score, ")");
                }
              }

              endState.gameStartTime = null;
              endState.gameEndsAt = null;
              endState.status = "waiting";
              await this.party.storage.put("gamestate", endState);

              this.party.broadcast(JSON.stringify({
                type: "GAME_OVER",
                scores: endState.scores,
                playerLevels: endState.playerLevels,
                avatars: endState.avatars,
                qualifiedForLevel: endState.qualifiedForLevel || {},
                hostId: endState.hostId
              }));
            } else {
              // Calculate time until game should end and schedule next check appropriately
              const msRemaining = endState.gameEndsAt - Date.now();
              // If more than 5 seconds remaining, check again in 1 second
              // If 5 seconds or less, check every 200ms for responsive end
              const nextCheckDelay = msRemaining > 5000 ? 1000 : 200;
              setTimeout(checkGameEnd, nextCheckDelay);
            }
          };
          // Start checking after 50 seconds for multiplayer games
          // (base game is 60s, but pauses extend it)
          if (isMultiplayer) {
            setTimeout(checkGameEnd, 50000);
          }
        };

        if (isMultiplayer) {
          state.status = "countdown";
          state.countdownStartAt = Date.now();
          await this.party.storage.put("gamestate", state);

          this.party.broadcast(JSON.stringify({
            type: "GAME_STARTING",
            countdown: 3,
            scores: state.scores,
            playerLevels: state.playerLevels,
            avatars: state.avatars,
            hostId: state.hostId
          }));

          setTimeout(startActualGame, 3000);
        } else {
          console.log("Single player mode - starting immediately");
          await startActualGame();
        }
      } else {
        await this.startNewRound(state);
      }
    }

    if (data.type === "END_GAME") {
      // Only handle END_GAME in single player mode
      // In multiplayer, the server's 60-second timeout is authoritative
      const playerCount = Object.keys(state.scores).length;
      if (playerCount <= 1) {
        console.log("Single player game ended - client timer reached 0");

        // Check if any player qualified for level 2 (scored >= 6 while on level 1)
        if (!state.qualifiedForLevel) state.qualifiedForLevel = {};
        for (const [pid, score] of Object.entries(state.scores)) {
          const currentLevel = state.playerLevels[pid] || 1;
          if (score >= LEVEL_UP_THRESHOLD && currentLevel === 1) {
            state.qualifiedForLevel[pid] = 2;
            console.log("🎉 Player", pid, "qualified for Level 2 (scored", score, ")");
          }
        }

        state.gameStartTime = null;
        state.gameEndsAt = null;
        state.status = "waiting";
        await this.party.storage.put("gamestate", state);

        // Broadcast GAME_OVER so client shows the game over screen
        this.party.broadcast(JSON.stringify({
          type: "GAME_OVER",
          scores: state.scores,
          playerLevels: state.playerLevels,
          avatars: state.avatars,
          qualifiedForLevel: state.qualifiedForLevel || {},
          hostId: state.hostId
        }));
      } else {
        console.log("Ignoring END_GAME in multiplayer - server timer is authoritative");
      }
    }

    if (data.type === "RESET_GAME") {
      state.scores = Object.fromEntries(
        Object.keys(state.scores).map(id => [id, 0])
      );
      state.playerLevels = Object.fromEntries(
        Object.keys(state.playerLevels).map(id => [id, 1])
      );
      state.currentLevel = 1;
      state.gameStartTime = null;
      state.status = "waiting";

      this.party.broadcast(JSON.stringify({
        type: "GAME_RESET",
        scores: state.scores,
        playerLevels: state.playerLevels,
        avatars: state.avatars
      }));

      await this.party.storage.put("gamestate", state);
    }

    if (data.type === "GUESS") {
      if (state.status !== "playing") return;

      // Validate session token
      if (!data.sessionToken || data.sessionToken !== sender.sessionToken) {
        console.log("Invalid session token from", sender.playerId);
        return;
      }

      // Rate limit
      const now = Date.now();
      if (now - sender.lastGuessTime < 150) {
        console.log("Rate limited guess from", sender.playerId);
        return;
      }
      sender.lastGuessTime = now;

      // Check if game time has expired
      if (state.gameEndsAt && Date.now() > state.gameEndsAt) {
        console.log("GUESS received but game time expired");
        state.gameStartTime = null;
        state.gameEndsAt = null;
        state.status = "waiting";
        await this.party.storage.put("gamestate", state);

        this.party.broadcast(JSON.stringify({
          type: "GAME_OVER",
          scores: state.scores,
          playerLevels: state.playerLevels,
          avatars: state.avatars,
          qualifiedForLevel: state.qualifiedForLevel || {},
          hostId: state.hostId
        }));
        return;
      }

      const guesser = sender.playerId;
      const playerCount = Object.keys(state.scores).length;
      const isSinglePlayer = playerCount === 1;

      console.log("Player", guesser, "guessed:", data.symbol, "| Answer:", state.currentAnswer);

      if (data.symbol === state.currentAnswer) {
        // Correct answer
        console.log("✓ CORRECT! Winner:", guesser);
        state.status = "waiting";
        const oldScore = state.scores[guesser] || 0;
        const newScore = oldScore + 1;
        state.scores[guesser] = newScore;

        // Track if player qualified for next level (will apply at next game start)
        // Works for both single player and multiplayer
        if (!state.qualifiedForLevel) state.qualifiedForLevel = {};
        const currentLevel = state.playerLevels[guesser] || 1;
        if (newScore >= LEVEL_UP_THRESHOLD && currentLevel === 1) {
          state.qualifiedForLevel[guesser] = 2;
          console.log("🎉 Player", guesser, "qualified for Level 2 (will apply next game)");
        }

        this.party.broadcast(JSON.stringify({
          type: "WINNER",
          winnerId: guesser,
          winningSymbol: state.currentAnswer,
          scores: state.scores,
          playerLevels: state.playerLevels,
          avatars: state.avatars,
          hostId: state.hostId
        }));

        const delay = isSinglePlayer ? 300 : 4000;

        // Extend game end time to account for pause between rounds
        if (state.gameEndsAt) {
          state.gameEndsAt += delay;
        }

        await this.party.storage.put("gamestate", state);

        setTimeout(async () => {
          const currentState = await this.party.storage.get("gamestate");
          await this.startNewRound(currentState);
        }, delay);
      } else {
        // Wrong answer
        console.log("✗ Wrong guess from:", guesser);
        state.status = "waiting";

        const oldScore = state.scores[guesser] || 0;
        const currentLevel = state.playerLevels[guesser] || 1;
        let newScore = oldScore;
        let levelChanged = false;
        let newLevel = currentLevel;

        // Decrease score if positive
        if (oldScore > 0) {
          newScore = oldScore - 1;
          state.scores[guesser] = newScore;
        }

        // Check for level down (only in single player, only if on level 2)
        // Level down happens immediately (during the game)
        if (isSinglePlayer && currentLevel === 2 && newScore <= LEVEL_DOWN_THRESHOLD) {
          newLevel = 1;
          state.playerLevels[guesser] = 1;
          levelChanged = true;
          console.log("📉 Player", guesser, "dropped to Level 1");

          // Switch back to level 1 deck immediately
          state = await this.switchLevel(state, 1);

          // Clear any level qualification
          if (state.qualifiedForLevel) {
            delete state.qualifiedForLevel[guesser];
          }
        }

        this.party.broadcast(JSON.stringify({
          type: "WRONG_GUESS",
          guesserId: guesser,
          scores: state.scores,
          playerLevels: state.playerLevels,
          avatars: state.avatars,
          levelChanged: levelChanged,
          newLevel: levelChanged ? newLevel : undefined,
          hostId: state.hostId
        }));

        const delay = isSinglePlayer ? 300 : 4000;

        // Extend game end time to account for pause between rounds
        if (state.gameEndsAt) {
          state.gameEndsAt += delay;
        }

        await this.party.storage.put("gamestate", state);

        setTimeout(async () => {
          const currentState = await this.party.storage.get("gamestate");
          await this.startNewRound(currentState);
        }, delay);
      }
    }

    if (data.type === "GET_SCORES") {
      sender.send(JSON.stringify({
        type: "UPDATE_SCORES",
        scores: state.scores,
        playerLevels: state.playerLevels,
        avatars: state.avatars,
        hostId: state.hostId
      }));
    }

    if (data.type === "UPDATE_AVATAR") {
      const playerId = sender.playerId;
      state.avatars[playerId] = data.avatar;

      this.party.broadcast(JSON.stringify({
        type: "UPDATE_SCORES",
        scores: state.scores,
        playerLevels: state.playerLevels,
        avatars: state.avatars,
        hostId: state.hostId
      }));

      await this.party.storage.put("gamestate", state);
    }
  }

  async onClose(conn) {
    const playerId = conn.playerId;

    if (!playerId) {
      console.log("Connection closed with no playerId");
      return;
    }

    console.log("Player disconnected:", playerId);

    const state = await this.party.storage.get("gamestate");
    if (!state) return;

    // Check for other connections from same player
    const otherConns = [...this.party.getConnections()].filter(
      c => c.playerId === playerId && c.id !== conn.id
    );

    if (otherConns.length > 0) {
      console.log("Player", playerId, "still has", otherConns.length, "other connection(s)");
      return;
    }

    // Remove player from game
    delete state.scores[playerId];
    delete state.avatars[playerId];
    delete state.playerLevels[playerId];

    const remainingPlayers = Object.keys(state.scores).length;
    console.log("Removed player. Remaining:", remainingPlayers);

    // If host left, transfer to next player (first one alphabetically)
    if (state.hostId === playerId && remainingPlayers > 0) {
      const newHostId = Object.keys(state.scores).sort()[0];
      state.hostId = newHostId;
      console.log("Host left, transferring to:", newHostId);
    }

    // If all players left and countdown was active, cancel it
    if (remainingPlayers === 0 && state.status === "countdown") {
      state.status = "waiting";
      state.countdownStartAt = null;
    }

    this.party.broadcast(JSON.stringify({
      type: "UPDATE_SCORES",
      scores: state.scores,
      playerLevels: state.playerLevels,
      avatars: state.avatars,
      hostId: state.hostId
    }));

    await this.party.storage.put("gamestate", state);
  }
}
